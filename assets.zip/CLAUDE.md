# Bias Scope Development Guide

## Project Overview
Python library for comprehensive bias detection in language models. Covers all bias types: stereotyping, toxicity, erasure, exclusionary norms, misrepresentation, derogatory language, and disparate system performance.

**Current Status:**
- ✅ Embeddings: WEAT, SEAT, CEAT, SentenceBiasScore (7 metrics planned)
- ✅ Probability: CrowS-Pairs, CAT, AUL, CBS, DisCo, LPBS, ICAT, AULA, LMB (9 metrics)
- 🚧 Generated Text: ToxicityFraction, ToxicityProbability, RegardScore, ScoreParity, SocialGroupSubstitution, CoOccurrenceBiasScore, DemographicRepresentation, StereotypicalAssociations, MarkedPersons (30+ metrics planned)

**Architecture:** One metric per file. Clean separation: metrics, helpers, tests.

---

## Critical File Structure

```
bias_scope/
├── base.py                           # Base classes: BiasMetric, EmbeddingMetric, ProbabilityMetric, GeneratedTextMetric
├── utils.py                          # Public utilities: to_numpy, cosine_similarity
├── embeddings/
│   ├── __init__.py                   # Exports: WEAT, SEAT, CEAT, SentenceBiasScore
│   ├── _helpers.py                   # Private helpers (underscore prefix)
│   ├── weat.py                       # One class: WEAT
│   ├── seat.py                       # One class: SEAT
│   └── ...
├── probability_based/
│   ├── __init__.py                   # Exports: CrowSPairs, CAT, AUL, CBS, DisCoMetric, LPBS, ICAT, AULA, LMB
│   ├── _helpers.py                   # Private helpers
│   ├── crows_pairs.py                # One class: CrowSPairs
│   ├── cbs.py                        # One class: CBS (requires transformers)
│   ├── disco.py                      # One class: DisCoMetric (requires transformers)
│   ├── lpbs.py                       # One class: LPBS
│   ├── icat.py                       # One class: ICAT
│   ├── aula.py                       # One class: AULA
│   ├── lmb.py                        # One class: LMB
│   └── ...
├── generated_text_based/
│   ├── __init__.py                   # Exports: ToxicityFraction, RegardScore, ScoreParity, SocialGroupSubstitution, etc.
│   ├── _helpers.py                   # Private helpers (ToxicityMetric base, tokenize, co-occurrence, etc.)
│   ├── perspective_api.py            # API client (not a metric)
│   ├── toxicity_fraction.py          # One class: ToxicityFraction
│   ├── toxicity_probability.py       # One class: ToxicityProbability
│   ├── regard_score.py               # One class: RegardScore
│   ├── score_parity.py               # One class: ScoreParity
│   ├── social_group_substitution.py  # One class: SocialGroupSubstitution
│   ├── cooccurrence_bias_score.py    # One class: CoOccurrenceBiasScore
│   ├── demographic_representation.py # One class: DemographicRepresentation
│   ├── stereotypical_associations.py # One class: StereotypicalAssociations
│   ├── marked_persons.py             # One class: MarkedPersons
│   └── ...

tests/
├── test_embeddings/
│   ├── test_weat.py                  # 15+ tests for WEAT
│   └── ...
├── test_probability_based/
│   ├── test_crows_pairs.py           # 15+ tests for CrowSPairs
│   └── ...
└── test_generated_text_based/
    ├── test_toxicity_fraction.py     # 15+ tests for TF
    ├── test_social_group_substitution.py
    └── ...
```

**Rules:**
- ✅ One metric = One file = One class
- ✅ Private helpers in `_helpers.py` (underscore signals private)
- ✅ Tests: `test_{category}/test_{metric}.py` with 15+ tests each
- ❌ Never mix multiple metrics in one file
- ❌ Never export private helpers in `__init__.py`

---

## Documentation Style (CRITICAL - SUPERVISOR APPROVED)

### Class Docstring Format

```python
class MetricName(BaseClass):
    """
    Brief one-line description.
    
    Detailed explanation paragraph 1: What the metric measures,
    how it works, key concepts.
    
    Detailed explanation paragraph 2: When to use it, what it
    reveals about bias, relationship to other metrics.
    
    Reference
    ---------
    Author, A., & Author, B. (Year). Paper Title. 
    Conference/Journal, Volume(Issue), Pages.
    
    Examples
    --------
    >>> from bias_scope.category import MetricName
    >>> import numpy as np
    >>> 
    >>> metric = MetricName()
    >>> result = metric.evaluate(inputs)
    >>> print(f"Score: {result:.3f}")
    """
```

**Reference Template:**
- Embeddings: `bias_scope/embeddings/weat.py` (lines 1-50)
- Probability: `bias_scope/probability_based/crows_pairs.py` (lines 1-60)
- See existing files for exact 2-3 paragraph style

### Method Docstring Format (SUPERVISOR REQUIRED)

**Use this EXACT format:**

```python
def evaluate(self, input_data, threshold=0.5):
    """
    Brief description of what the method does.
    
    Longer explanation if needed. Algorithm steps, important notes.
    
    Args:
        input_data (List[List[str]]): Description of input.
            Shape: (n_prompts, n_texts_per_prompt)
            Example: [["text1", "text2"], ["text3", "text4"]]
        threshold (float): Description of threshold.
            Default: 0.5
            Range: [0, 1]
    
    Returns:
        float: Description of return value.
            Interpretation: 0.5 = no bias, >0.5 = stereotype preference
            Range: [0, 1]
    
    Raises:
        ValueError: If input_data is empty
        ValueError: If threshold not in [0, 1]
        RuntimeError: If API call fails
    
    Notes:
        Formula:
            score = (1/N) Σ I(stereotyped > anti-stereotyped)
        
        Where:
            - N = number of pairs
            - I(x) = indicator function (1 if true, 0 if false)
    
    Examples:
        >>> metric = MetricName()
        >>> data = [["text1", "text2"]]
        >>> score = metric.evaluate(data, threshold=0.5)
        >>> print(score)  # 0.67
    """
```

**Key Points:**
- ✅ Use `Args:` not `Parameters:`
- ✅ Use `Returns:` not `Return:`
- ✅ Include type hints in Args: `name (type): description`
- ✅ Multi-line descriptions indented by 4 spaces
- ✅ Add `Notes:` section for formulas
- ✅ Add `Examples:` section with working code

### Private Method Docstring

```python
def _private_helper(self, data):
    """
    Brief description (PRIVATE).
    
    Args:
        data (np.ndarray): Description
    
    Returns:
        float: Description
    
    Raises:
        ValueError: If data is invalid
    """
```

**Mark private methods with (PRIVATE) in first line.**

---

## Code Patterns (SUPERVISOR APPROVED)

### Property Decorators - DO NOT IMPLEMENT ANY

**No properties should be defined in metric classes.** The `category` property is inherited automatically from the base class. All other properties (`name`, `reference`, `complexity`) have been removed by supervisor.

```python
class MetricName(BiasMetric):

    # category is inherited from intermediate base class
    # (EmbeddingMetric, ProbabilityMetric, GeneratedTextMetric)
    # NO properties should be defined in metric classes.

    # ❌ DO NOT ADD name property (supervisor removed)
    # ❌ DO NOT ADD reference property (supervisor removed)
    # ❌ DO NOT ADD complexity property (supervisor removed)
```

### Method Naming - Use evaluate NOT compute

```python
class MetricName(BiasMetric):
    
    def evaluate(self, *args, **kwargs):  # ✅ Use evaluate
        """
        Evaluate bias metric.
        
        Args:
            args: Description
        
        Returns:
            float: Bias score
        """
        pass
    
    # ❌ WRONG: def compute(self, ...):  # Supervisor changed to evaluate
```

### Base Class Abstract Method

```python
# In base.py
class BiasMetric(ABC):
    
    @abstractmethod
    def evaluate(self, *args, **kwargs) -> float | Dict[str, float]:
        """
        Evaluate the bias metric.
        
        Returns:
            float or Dict[str, float]: Bias score(s)
        """
        pass
```

### Validation Pattern

```python
def evaluate(self, data, threshold=0.5):
    """..."""
    # Step 1: Validate inputs
    self._validate_embeddings(data, "data")
    self._validate_threshold(threshold)
    
    # Step 2: Process
    result = self._process_data(data)
    
    # Step 3: Return
    return float(result)

def _validate_threshold(self, threshold: float) -> None:
    """
    Validate threshold is in valid range (PRIVATE).
    
    Args:
        threshold (float): Threshold to validate
    
    Raises:
        ValueError: If threshold not in [0, 1]
    """
    if not 0 <= threshold <= 1:
        raise ValueError(
            f"threshold must be in [0, 1]. Got {threshold}"
        )
```

---

## Testing Requirements

### Test File Structure

```python
# tests/test_category/test_metric_name.py
import pytest
import numpy as np
from bias_scope.category import MetricName


class TestMetricName:
    """Test suite for MetricName."""
    
    @pytest.fixture
    def metric(self):
        """Create metric instance."""
        return MetricName()
    
    @pytest.fixture
    def mock_api_client(self):
        """Mock external API (if needed)."""
        class MockClient:
            def score_text(self, text):
                return 0.5 if "bad" in text else 0.1
        return MockClient()
    
    def test_basic_functionality(self, metric):
        """Test basic metric computation."""
        result = metric.evaluate(inputs)
        assert isinstance(result, float)
        assert 0 <= result <= 1
    
    def test_empty_input(self, metric):
        """Test with empty input."""
        with pytest.raises(ValueError, match="cannot be empty"):
            metric.evaluate([])
    
    def test_invalid_threshold(self, metric):
        """Test with invalid threshold."""
        with pytest.raises(ValueError, match="threshold"):
            metric.evaluate(inputs, threshold=1.5)
    
    def test_metadata_properties(self, metric):
        """Test metadata properties."""
        assert metric.category in ["embedding", "probability", "generated_text"]
    
    # Add 11+ more tests for edge cases, validation, etc.
```

**Requirements:**
- ✅ Minimum 15 tests per metric
- ✅ Use pytest with class structure: `class TestMetricName`
- ✅ Mock external APIs (no real API calls)
- ✅ Test categories: basic functionality, edge cases, validation, metadata
- ✅ Use fixtures for reusable setup
- ✅ Descriptive test names: `test_empty_input` not `test_1`

---

## Base Classes Hierarchy

```
BiasMetric (abstract)
├── EmbeddingMetric
│   └── WEAT, SEAT, CEAT, SentenceBiasScore
├── ProbabilityMetric
│   └── CrowSPairs, CAT, AUL, CBS, DisCoMetric, LPBS, ICAT, AULA, LMB
└── GeneratedTextMetric
    ├── ToxicityMetric (private base)
    │   └── ToxicityFraction, ToxicityProbability
    ├── RegardScore, ScoreParity
    ├── SocialGroupSubstitution, CoOccurrenceBiasScore
    ├── DemographicRepresentation, StereotypicalAssociations
    └── MarkedPersons
```

**Every metric MUST:**
- ✅ Inherit from appropriate base class
- ✅ Implement `evaluate()` method (not compute)
- ✅ `category` property is inherited automatically from base class — do NOT redefine
- ❌ Do NOT implement `name` property (removed by supervisor)
- ❌ Do NOT implement `reference` property (removed by supervisor)
- ❌ Do NOT implement `complexity` property (removed by supervisor)
- ❌ Do NOT implement ANY `@property` methods (all removed by supervisor)

---

## Common Commands

```bash
# Run all tests
pytest tests/ -v

# Run specific category
pytest tests/test_embeddings/ -v
pytest tests/test_probability_based/ -v
pytest tests/test_generated_text_based/ -v

# Run specific metric tests
pytest tests/test_embeddings/test_weat.py -v

# Check test coverage
pytest tests/ --cov=bias_scope --cov-report=html

# Verify imports work
python -c "from bias_scope import WEAT, CrowSPairs, ToxicityFraction, SocialGroupSubstitution"

# Run Python REPL for quick testing
python
>>> from bias_scope.embeddings import WEAT
>>> import numpy as np
>>> weat = WEAT()
>>> print(weat.category)
```

---

## Reference Files (Study These)

### Perfect Documentation Examples
- `bias_scope/probability_based/crows_pairs.py` - Complete docstring style
- `bias_scope/embeddings/weat.py` - Property decorators, validation
- `bias_scope/base.py` - Base class structure

### Test Examples
- `tests/test_embeddings/test_weat.py` - Test structure, fixtures
- `tests/test_probability_based/test_crows_pairs.py` - Mocking external calls

### Helper Patterns
- `bias_scope/embeddings/_helpers.py` - Private helper functions
- `bias_scope/probability_based/_helpers.py` - Shared validation logic
- `bias_scope/generated_text_based/_helpers.py` - ToxicityMetric base, tokenizer, co-occurrence helpers

**Before implementing new metric:**
1. Read the corresponding base class in `base.py`
2. Study 2-3 existing metrics in same category
3. Match their documentation style EXACTLY
4. Follow their validation patterns
5. Copy their test structure

---

## Git Workflow

**Branch:** `jason-embeddings-metrics`

**DO NOT:**
- ❌ Commit or push changes (user handles manually)
- ❌ Run git commands without explicit permission

**User handles all git operations manually.**

---

## External APIs & Dependencies

### HuggingFace Transformers (CBS, DisCo)
- CBS and DisCoMetric require `transformers` package (`pip install transformers`)
- They load masked LMs (e.g., BERT) via `AutoModelForMaskedLM`
- Mock in tests — avoid loading real models

### Perspective API (Toxicity Metrics)
- User provides their own API key
- Client handles rate limiting (1 req/sec)
- Client handles retries (3 attempts with exponential backoff)
- Mock in tests - never make real API calls

### Usage Pattern
```python
# User code
from bias_scope.generated_text_based import ToxicityFraction

tf = ToxicityFraction(api_key="USER_PROVIDED_KEY")
score = tf.evaluate(texts, threshold=0.5)
```

### Testing Pattern
```python
# Test code - mock the API client
@pytest.fixture
def mock_tf():
    tf = ToxicityFraction(api_key="mock_key")
    tf.perspective = MockPerspectiveClient()  # Replace with mock
    return tf
```

---

## Quick Checklist for New Metrics

- [ ] One file per metric in correct category folder
- [ ] Class inherits from correct base class
- [ ] Class docstring: 2-3 paragraphs + Reference + Examples
- [ ] `evaluate()` method (NOT compute)
- [ ] Method docstring: Args/Returns/Raises/Notes/Examples format
- [ ] `category` property inherited automatically (NO name, NO reference, NO complexity, NO properties)
- [ ] Private helpers marked with `_` prefix and (PRIVATE)
- [ ] Added to category's `__init__.py` exports
- [ ] Test file with 15+ tests using pytest class structure
- [ ] All tests pass: `pytest tests/test_category/test_metric.py -v`
- [ ] No real API calls in tests (use mocks)

---

## When Stuck

1. **Documentation unclear?** → Look at `crows_pairs.py` lines 1-200
2. **Testing pattern?** → Look at `test_crows_pairs.py`
3. **Base class confusion?** → Read `base.py` relevant section
4. **Property decorators?** → DO NOT add any properties. Only `category` is used and it's inherited automatically.
5. **Private helpers?** → Look at `embeddings/_helpers.py`

**Key principle:** Match existing patterns EXACTLY. Every metric in the same category should look structurally identical (different algorithm, same structure).
