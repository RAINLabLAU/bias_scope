"""Test embeddings module."""
